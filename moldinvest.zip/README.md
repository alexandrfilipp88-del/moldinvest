# MOLDINVEST

Financial consulting & transparent investment advisory website.

## Stack

- **Next.js 14** (App Router)
- **React 18**
- **Chart.js + react-chartjs-2** for performance charts
- **Google Fonts** (DM Serif Display + Inter)
- No CSS framework — all styling is inline React

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Deploy to Vercel

### Option A — Vercel CLI

```bash
npm i -g vercel
vercel
```

### Option B — GitHub + Vercel dashboard

1. Push this repo to GitHub
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import the GitHub repository
4. Framework preset: **Next.js** (auto-detected)
5. Click **Deploy** — no environment variables needed for the UI

## Project structure

```
moldinvest/
├── src/
│   └── app/
│       ├── layout.jsx   # HTML shell + metadata
│       └── page.jsx     # Full single-page UI
├── package.json
├── next.config.mjs
└── README.md
```

## Customisation

All data (holdings, ticker items, team, services, insights) is defined as constants at the top of `src/app/page.jsx` — easy to swap out for real API calls later.

Charts use `react-chartjs-2` and rebuild automatically when the theme toggle switches between dark and light mode.
