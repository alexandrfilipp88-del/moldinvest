export const metadata = {
  title: 'MOLDINVEST — Transparent Investment & Financial Advisory',
  description: 'MOLDINVEST publishes its full portfolio in real time. We invest our own capital first, then advise yours. Financial consulting, audit, and investment advisory based in Moldova.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0 }}>{children}</body>
    </html>
  );
}
