'use client';

import { useState, useEffect, useRef } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
} from 'chart.js';
import { Line } from 'react-chartjs-2';

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Filler, Tooltip);

const MONTHS = ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
const APEX_DATA = [100, 103, 102, 107, 110, 108, 113, 116, 114, 119, 116, 118.4];
const SPX_DATA  = [100, 101, 102, 104, 103, 105, 106, 108, 107, 110, 111, 112.1];

const TICKER_ITEMS = [
  { name: 'AAPL',  price: '$193.42',  delta: '+1.24%', up: true },
  { name: 'MSFT',  price: '$415.80',  delta: '+0.87%', up: true },
  { name: 'AMZN',  price: '$184.50',  delta: '+2.10%', up: true },
  { name: 'BRK.B', price: '$382.10',  delta: '-0.33%', up: false },
  { name: 'GOOGL', price: '$176.24',  delta: '+0.55%', up: true },
  { name: 'US10Y', price: '4.32%',    delta: '-0.05%', up: false },
  { name: 'SPX',   price: '5,431.20', delta: '+0.72%', up: true },
  { name: 'NVDA',  price: '$892.60',  delta: '+3.41%', up: true },
];

const HOLDINGS = [
  { name: 'Apple Inc',     ticker: 'AAPL',  value: '€482,100', pnl: '+22.4%', weight: '10.0%', up: true },
  { name: 'Microsoft',     ticker: 'MSFT',  value: '€415,800', pnl: '+31.7%', weight: '8.6%',  up: true },
  { name: 'Berkshire B',   ticker: 'BRK.B', value: '€363,000', pnl: '+8.2%',  weight: '7.5%',  up: true },
  { name: 'EUR Corp Bond', ticker: 'IEAC',  value: '€620,000', pnl: '+4.1%',  weight: '12.9%', up: true },
  { name: 'Amazon',        ticker: 'AMZN',  value: '€294,200', pnl: '-2.8%',  weight: '6.1%',  up: false },
];

const SERVICES = [
  {
    icon: '💼',
    name: 'Financial Consulting',
    desc: 'Accounting advisory, budget planning, cash flow optimisation, and comprehensive financial reporting for businesses.',
  },
  {
    icon: '🛡️',
    name: 'Audit & Compliance',
    desc: 'Internal audits, risk assessment frameworks, and regulatory compliance checks tailored to your sector.',
  },
  {
    icon: '📈',
    name: 'Investment Advisory',
    desc: 'Portfolio construction, risk profiling, asset allocation strategy, and long-term retirement or income planning.',
  },
];

const INSIGHTS = [
  { cat: 'Market Analysis', title: 'Why we increased tech exposure in Q2 2025', date: 'June 8, 2025' },
  { cat: 'Portfolio Update', title: 'Bond duration strategy in a high-rate environment', date: 'May 22, 2025' },
  { cat: 'Macro', title: 'ECB policy divergence and what it means for EU equities', date: 'May 14, 2025' },
];

const TEAM = [
  { initials: 'MV', name: 'Marcus Vogel',  role: 'CIO & Co-Founder · 22 yrs experience' },
  { initials: 'EK', name: 'Elena Kraft',   role: 'Head of Consulting · CFA, CFP' },
  { initials: 'JL', name: 'Jonas Lehmann', role: 'Risk & Compliance Lead' },
];

const PRINCIPLES = [
  'We publish our full portfolio and all trades — no selective disclosure.',
  'We apply the same risk frameworks to our own capital as to client capital.',
  'Fees are performance-linked, not volume-linked.',
  'Every investment thesis is published before entry, not after.',
];

function getColors(dark) {
  return {
    accent: dark ? '#00D4AA' : '#007A62',
    muted:  dark ? '#8BA4C8' : '#5A7399',
    grid:   dark ? 'rgba(30,58,95,0.5)' : 'rgba(208,220,240,0.8)',
  };
}

function HeroChart({ dark }) {
  const c = getColors(dark);
  return (
    <Line
      data={{
        labels: MONTHS,
        datasets: [{
          data: APEX_DATA,
          borderColor: c.accent,
          borderWidth: 2,
          pointRadius: 0,
          tension: 0.4,
          fill: true,
          backgroundColor: dark ? 'rgba(0,212,170,0.08)' : 'rgba(0,122,98,0.07)',
        }],
      }}
      options={{
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { enabled: false } },
        scales: {
          x: { display: false },
          y: { display: false, min: 96, max: 124 },
        },
      }}
    />
  );
}

function PerfChart({ dark }) {
  const c = getColors(dark);
  return (
    <Line
      data={{
        labels: MONTHS,
        datasets: [
          {
            label: 'MOLDINVEST',
            data: APEX_DATA,
            borderColor: c.accent,
            borderWidth: 2,
            pointRadius: 0,
            tension: 0.4,
            fill: false,
          },
          {
            label: 'S&P 500',
            data: SPX_DATA,
            borderColor: c.muted,
            borderWidth: 2,
            borderDash: [5, 4],
            pointRadius: 0,
            tension: 0.4,
            fill: false,
          },
        ],
      }}
      options={{
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: {
            ticks: { color: c.muted, font: { size: 11 } },
            grid: { color: c.grid },
            border: { color: 'transparent' },
          },
          y: {
            ticks: { color: c.muted, font: { size: 11 }, callback: v => `+${(v - 100).toFixed(0)}%` },
            grid: { color: c.grid },
            border: { color: 'transparent' },
            min: 98,
            max: 124,
          },
        },
      }}
    />
  );
}

export default function Home() {
  const [dark, setDark] = useState(true);
  const [activeTime, setActiveTime] = useState('1Y');

  const d = {
    bg:     dark ? '#0A1628' : '#F4F7FF',
    bg2:    dark ? '#0F2447' : '#FFFFFF',
    bg3:    dark ? '#1A3A6B' : '#E8F0FD',
    border: dark ? '#1E3A5F' : '#D0DCF0',
    text:   dark ? '#F0F4FF' : '#0A1628',
    muted:  dark ? '#8BA4C8' : '#5A7399',
    accent: dark ? '#00D4AA' : '#007A62',
    neg:    dark ? '#FF6B6B' : '#D93025',
    footer: dark ? '#060E1A' : '#E8F0FD',
  };

  const tickerItems = [...TICKER_ITEMS, ...TICKER_ITEMS];

  return (
    <div style={{ fontFamily: "'Inter', sans-serif", background: d.bg, color: d.text, minWidth: 0, transition: 'background 0.25s, color 0.25s' }}>

      {/* Google Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Inter:wght@400;500;600&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: ${d.bg}; }
        @keyframes scroll { 0% { transform: translateX(0); } 100% { transform: translateX(-50%); } }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        .ticker-track { display: flex; gap: 40px; white-space: nowrap; animation: scroll 30s linear infinite; }
        .live-dot { width: 7px; height: 7px; background: ${d.accent}; border-radius: 50%; animation: pulse 2s ease-in-out infinite; display: inline-block; }
        a { cursor: pointer; }
        input, textarea, select { background: ${d.bg2}; border: 1px solid ${d.border}; border-radius: 4px; padding: 10px 14px; font-size: 14px; color: ${d.text}; outline: none; font-family: 'Inter', sans-serif; width: 100%; transition: border-color 0.2s; }
        input:focus, textarea:focus { border-color: ${d.accent}; }
        textarea { height: 100px; resize: vertical; }
        select { appearance: none; }
      `}</style>

      {/* NAV */}
      <nav style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 40px', height: 64, background: d.bg, borderBottom: `1px solid ${d.border}`, position: 'sticky', top: 0, zIndex: 100, transition: 'background 0.25s, border-color 0.25s' }}>
        <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 20, color: d.text }}>
          <span style={{ color: d.accent }}>MOLD</span>INVEST
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 28 }}>
          {['Portfolio', 'Services', 'Insights', 'About'].map(l => (
            <a key={l} style={{ fontSize: 13, color: d.muted, textDecoration: 'none', letterSpacing: '0.3px' }}>{l}</a>
          ))}
          {/* Theme toggle */}
          <div style={{ background: d.bg3, border: `1px solid ${d.border}`, borderRadius: 20, padding: 4, display: 'flex', gap: 2 }}>
            {[{ mode: 'dark', icon: '🌙' }, { mode: 'light', icon: '☀️' }].map(({ mode, icon }) => (
              <button
                key={mode}
                onClick={() => setDark(mode === 'dark')}
                style={{ width: 28, height: 24, borderRadius: 16, border: 'none', background: (dark ? mode === 'dark' : mode === 'light') ? d.accent : 'transparent', cursor: 'pointer', fontSize: 13, display: 'flex', alignItems: 'center', justifyContent: 'center', color: (dark ? mode === 'dark' : mode === 'light') ? (dark ? '#0A1628' : '#fff') : d.muted, transition: 'background 0.2s' }}
                aria-label={`${mode} mode`}
              >{icon}</button>
            ))}
          </div>
        </div>
        <button style={{ background: d.accent, color: dark ? '#0A1628' : '#fff', fontSize: 13, fontWeight: 600, border: 'none', padding: '8px 18px', borderRadius: 4, cursor: 'pointer', letterSpacing: '0.2px' }}>
          Book Consultation
        </button>
      </nav>

      {/* TICKER */}
      <div style={{ background: d.bg2, padding: '8px 0', overflow: 'hidden', borderBottom: `1px solid ${d.border}` }}>
        <div className="ticker-track">
          {tickerItems.map((t, i) => (
            <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12 }}>
              <span style={{ color: d.muted, fontWeight: 500 }}>{t.name}</span>
              <span style={{ color: d.text }}>{t.price}</span>
              <span style={{ color: t.up ? d.accent : d.neg }}>{t.delta}</span>
            </span>
          ))}
        </div>
      </div>

      {/* HERO */}
      <div style={{ padding: '60px 40px 0', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 48, alignItems: 'start', maxWidth: 1200, margin: '0 auto' }}>
        <div>
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, background: d.bg2, border: `1px solid ${d.border}`, padding: '5px 12px', borderRadius: 20, fontSize: 11, color: d.muted, marginBottom: 20 }}>
            <span className="live-dot" /> Portfolio updated daily
          </div>
          <h1 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 46, lineHeight: 1.1, color: d.text, marginBottom: 16 }}>
            We invest our<br />money <span style={{ color: d.accent }}>first.</span><br />Then advise yours.
          </h1>
          <p style={{ fontSize: 15, color: d.muted, lineHeight: 1.7, marginBottom: 32, maxWidth: 420 }}>
            MOLDINVEST publishes every position, every return, every trade. Full portfolio transparency — because advice backed by skin in the game earns trust.
          </p>
          <div style={{ display: 'flex', gap: 12 }}>
            <button style={{ background: d.accent, color: dark ? '#0A1628' : '#fff', fontSize: 13, fontWeight: 600, border: 'none', padding: '11px 22px', borderRadius: 4, cursor: 'pointer' }}>View Live Portfolio</button>
            <button style={{ background: 'transparent', color: d.text, fontSize: 13, fontWeight: 500, border: `1px solid ${d.border}`, padding: '11px 22px', borderRadius: 4, cursor: 'pointer' }}>Book a Consultation</button>
          </div>
          <div style={{ display: 'flex', gap: 32, marginTop: 40, paddingTop: 32, borderTop: `1px solid ${d.border}` }}>
            {[['€4.8M', 'Portfolio AUM'], ['+18.4%', 'YTD Return'], ['11 yrs', 'Track Record']].map(([val, lbl]) => (
              <div key={lbl}>
                <span style={{ fontFamily: "'DM Serif Display', serif", fontSize: 28, color: d.text, display: 'block' }}>{val}</span>
                <div style={{ fontSize: 11, color: d.muted, letterSpacing: '0.5px', textTransform: 'uppercase', marginTop: 2 }}>{lbl}</div>
              </div>
            ))}
          </div>
        </div>

        {/* PORTFOLIO PANEL */}
        <div style={{ background: d.bg2, border: `1px solid ${d.border}`, borderRadius: 8, padding: 24, marginBottom: 40, transition: 'background 0.25s' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 12, color: d.muted, textTransform: 'uppercase', letterSpacing: '0.8px' }}>Company Portfolio</div>
              <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 32, color: d.text }}>€4,812,430</div>
              <div style={{ fontSize: 13, color: d.accent, marginTop: 2 }}>▲ +€187,320 today (+3.9%)</div>
            </div>
            <div style={{ display: 'flex', gap: 4 }}>
              {['1M', '3M', '1Y', 'All'].map(t => (
                <button
                  key={t}
                  onClick={() => setActiveTime(t)}
                  style={{ background: activeTime === t ? d.bg3 : 'transparent', border: `1px solid ${activeTime === t ? d.bg3 : d.border}`, color: activeTime === t ? d.text : d.muted, fontSize: 11, padding: '4px 10px', borderRadius: 3, cursor: 'pointer' }}
                >{t}</button>
              ))}
            </div>
          </div>

          <div style={{ position: 'relative', height: 90 }}>
            <HeroChart dark={dark} />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginTop: 16 }}>
            {[['Stocks', '68%', d.accent], ['Bonds', '22%', d.muted], ['Cash', '10%', d.border]].map(([lbl, pct, color]) => (
              <div key={lbl} style={{ background: d.bg3, borderRadius: 4, padding: 12 }}>
                <div style={{ fontSize: 11, color: d.muted, marginBottom: 6 }}>{lbl}</div>
                <div style={{ height: 4, background: d.border, borderRadius: 2, marginBottom: 6 }}>
                  <div style={{ height: 4, width: pct, background: color, borderRadius: 2 }} />
                </div>
                <div style={{ fontSize: 16, fontWeight: 600, color: d.text }}>{pct}</div>
              </div>
            ))}
          </div>

          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12, marginTop: 16 }}>
            <thead>
              <tr>
                {['Holding', 'Value', 'P&L', 'Weight'].map((h, i) => (
                  <th key={h} style={{ color: d.muted, textAlign: i === 0 ? 'left' : 'right', padding: '6px 8px', borderBottom: `1px solid ${d.border}`, fontWeight: 500, fontSize: 11, letterSpacing: '0.3px' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {HOLDINGS.map(row => (
                <tr key={row.ticker} style={{ borderBottom: `1px solid ${d.border}` }}>
                  <td style={{ padding: '9px 8px', color: d.text }}>
                    {row.name}
                    <span style={{ background: d.bg3, color: d.muted, padding: '2px 6px', borderRadius: 3, fontSize: 10, marginLeft: 6 }}>{row.ticker}</span>
                  </td>
                  <td style={{ padding: '9px 8px', textAlign: 'right', color: d.text }}>{row.value}</td>
                  <td style={{ padding: '9px 8px', textAlign: 'right', color: row.up ? d.accent : d.neg }}>{row.pnl}</td>
                  <td style={{ padding: '9px 8px', textAlign: 'right', color: d.text }}>{row.weight}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div style={{ marginTop: 12, textAlign: 'right' }}>
            <a style={{ fontSize: 12, color: d.accent }}>View all 24 holdings →</a>
          </div>
        </div>
      </div>

      <hr style={{ border: 'none', borderTop: `1px solid ${d.border}`, margin: '0 40px' }} />

      {/* SERVICES */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '64px 40px' }}>
        <div style={{ fontSize: 11, color: d.accent, letterSpacing: '1.2px', textTransform: 'uppercase', marginBottom: 12 }}>What we do</div>
        <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 36, color: d.text, marginBottom: 14 }}>Advisory rooted<br />in real practice.</h2>
        <p style={{ fontSize: 15, color: d.muted, lineHeight: 1.7, maxWidth: 520 }}>We apply the same rigour to client portfolios that we apply to our own. No theoretical models — tested, live frameworks.</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, marginTop: 40 }}>
          {SERVICES.map(s => (
            <div key={s.name} style={{ background: d.bg2, border: `1px solid ${d.border}`, borderRadius: 6, padding: 24, transition: 'border-color 0.2s' }}>
              <div style={{ width: 36, height: 36, background: d.bg3, borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16, fontSize: 18 }}>{s.icon}</div>
              <div style={{ fontSize: 15, fontWeight: 600, color: d.text, marginBottom: 8 }}>{s.name}</div>
              <div style={{ fontSize: 13, color: d.muted, lineHeight: 1.6, marginBottom: 16 }}>{s.desc}</div>
              <a style={{ fontSize: 12, color: d.accent, letterSpacing: '0.3px' }}>Request consultation →</a>
            </div>
          ))}
        </div>
      </div>

      <hr style={{ border: 'none', borderTop: `1px solid ${d.border}`, margin: '0 40px' }} />

      {/* PERFORMANCE */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '64px 40px' }}>
        <div style={{ fontSize: 11, color: d.accent, letterSpacing: '1.2px', textTransform: 'uppercase', marginBottom: 12 }}>Transparency</div>
        <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 36, color: d.text, marginBottom: 14 }}>Our track record,<br />unfiltered.</h2>
        <p style={{ fontSize: 15, color: d.muted, lineHeight: 1.7, maxWidth: 520 }}>Performance benchmarked against the S&P 500. Updated weekly. Cherry-picking is prohibited by our own investment charter.</p>
        <div style={{ background: d.bg2, border: `1px solid ${d.border}`, borderRadius: 8, padding: 28, marginTop: 40 }}>
          <div style={{ display: 'flex', gap: 40, marginBottom: 24, flexWrap: 'wrap', alignItems: 'center' }}>
            {[['MOLDINVEST YTD', '+18.4%', d.accent], ['S&P 500 YTD', '+12.1%', d.muted], ['Outperformance', '+6.3pp', d.text]].map(([lbl, val, col]) => (
              <div key={lbl}>
                <div style={{ fontSize: 11, color: d.muted, marginBottom: 4 }}>{lbl}</div>
                <div style={{ fontSize: 24, fontWeight: 600, color: col }}>{val}</div>
              </div>
            ))}
            <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 16, fontSize: 12 }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, color: d.muted }}><span style={{ width: 16, height: 2, background: d.accent, display: 'inline-block' }} />MOLDINVEST</span>
              <span style={{ display: 'flex', alignItems: 'center', gap: 5, color: d.muted }}><span style={{ width: 16, height: 2, background: d.muted, display: 'inline-block' }} />S&P 500</span>
            </div>
          </div>
          <div style={{ position: 'relative', height: 200 }}>
            <PerfChart dark={dark} />
          </div>
        </div>
      </div>

      <hr style={{ border: 'none', borderTop: `1px solid ${d.border}`, margin: '0 40px' }} />

      {/* INSIGHTS */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '64px 40px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <div style={{ fontSize: 11, color: d.accent, letterSpacing: '1.2px', textTransform: 'uppercase', marginBottom: 12 }}>Research & Insights</div>
            <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 36, color: d.text }}>Market intelligence,<br />shared openly.</h2>
          </div>
          <a style={{ fontSize: 13, color: d.accent }}>All articles →</a>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, marginTop: 40 }}>
          {INSIGHTS.map(ins => (
            <div key={ins.title} style={{ border: `1px solid ${d.border}`, borderRadius: 6, overflow: 'hidden', background: d.bg2 }}>
              <div style={{ height: 100, background: d.bg3, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 36, color: d.border }}>📊</div>
              <div style={{ padding: 16 }}>
                <div style={{ fontSize: 10, color: d.accent, letterSpacing: '1px', textTransform: 'uppercase', marginBottom: 8 }}>{ins.cat}</div>
                <div style={{ fontSize: 14, fontWeight: 500, color: d.text, lineHeight: 1.4, marginBottom: 8 }}>{ins.title}</div>
                <div style={{ fontSize: 11, color: d.muted }}>{ins.date}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ABOUT STRIP */}
      <div style={{ background: d.bg2, borderTop: `1px solid ${d.border}`, borderBottom: `1px solid ${d.border}`, transition: 'background 0.25s' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '64px 40px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 11, color: d.accent, letterSpacing: '1.2px', textTransform: 'uppercase', marginBottom: 12 }}>Our philosophy</div>
            <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 36, color: d.text, marginBottom: 14 }}>Built on transparency<br />and discipline.</h2>
            <p style={{ fontSize: 14, color: d.muted, lineHeight: 1.7 }}>We were tired of advisors who recommend what they don't own. MOLDINVEST was founded on a single constraint: every strategy we sell, we run with our own capital first.</p>
            <ul style={{ marginTop: 24, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 14 }}>
              {PRINCIPLES.map(p => (
                <li key={p} style={{ display: 'flex', alignItems: 'flex-start', gap: 12, fontSize: 14, color: d.muted, lineHeight: 1.5 }}>
                  <span style={{ width: 6, height: 6, minWidth: 6, background: d.accent, borderRadius: '50%', marginTop: 7 }} />
                  {p}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div style={{ background: d.bg, border: `1px solid ${d.border}`, borderRadius: 8, padding: 24 }}>
              <div style={{ fontSize: 11, color: d.muted, letterSpacing: '0.8px', textTransform: 'uppercase', marginBottom: 20 }}>Team</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {TEAM.map(m => (
                  <div key={m.initials} style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                    <div style={{ width: 44, height: 44, borderRadius: '50%', background: d.bg3, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 600, color: d.accent, flexShrink: 0 }}>{m.initials}</div>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 500, color: d.text }}>{m.name}</div>
                      <div style={{ fontSize: 12, color: d.muted }}>{m.role}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CONTACT */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '64px 40px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'start' }}>
          <div>
            <div style={{ fontSize: 11, color: d.accent, letterSpacing: '1.2px', textTransform: 'uppercase', marginBottom: 12 }}>Get in touch</div>
            <h2 style={{ fontFamily: "'DM Serif Display', serif", fontSize: 36, color: d.text, marginBottom: 14 }}>Start with a<br />free consultation.</h2>
            <p style={{ fontSize: 14, color: d.muted, lineHeight: 1.7, marginBottom: 32 }}>We spend 30 minutes understanding your situation before recommending anything. No sales pitch.</p>
            {[
              { icon: '✉️', text: 'advisory@moldinvest.md' },
              { icon: '📞', text: '+373 22 123 456' },
              { icon: '📍', text: 'Bd. Ștefan cel Mare 65, Chișinău, Moldova' },
              { icon: '✈️', text: '@MoldinvestAdvisory' },
            ].map(item => (
              <div key={item.text} style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20, fontSize: 14, color: d.muted }}>
                <div style={{ width: 36, height: 36, background: d.bg3, borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, flexShrink: 0 }}>{item.icon}</div>
                <span>{item.text}</span>
              </div>
            ))}
          </div>
          <div>
            {[['Full name', 'text', 'Your name'], ['Email address', 'email', 'you@company.com']].map(([lbl, type, ph]) => (
              <div key={lbl} style={{ marginBottom: 16 }}>
                <label style={{ fontSize: 12, color: d.muted, display: 'block', marginBottom: 6, letterSpacing: '0.3px' }}>{lbl}</label>
                <input type={type} placeholder={ph} />
              </div>
            ))}
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12, color: d.muted, display: 'block', marginBottom: 6, letterSpacing: '0.3px' }}>I'm interested in</label>
              <select>
                {['Financial consulting', 'Investment advisory', 'Audit & compliance', 'Portfolio review'].map(o => <option key={o}>{o}</option>)}
              </select>
            </div>
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: 12, color: d.muted, display: 'block', marginBottom: 6, letterSpacing: '0.3px' }}>Message</label>
              <textarea placeholder="Tell us briefly about your situation..." />
            </div>
            <button style={{ background: d.accent, color: dark ? '#0A1628' : '#fff', fontSize: 14, fontWeight: 600, border: 'none', padding: '12px 28px', borderRadius: 4, cursor: 'pointer', width: '100%', marginTop: 4 }}>
              Send message
            </button>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <footer style={{ background: d.footer, borderTop: `1px solid ${d.border}`, padding: 40, display: 'flex', justifyContent: 'space-between', alignItems: 'center', transition: 'background 0.25s' }}>
        <div style={{ fontFamily: "'DM Serif Display', serif", fontSize: 18, color: d.text }}>
          <span style={{ color: d.accent }}>MOLD</span>INVEST
        </div>
        <div style={{ display: 'flex', gap: 24 }}>
          {['Privacy', 'Legal', 'Disclosures', 'GDPR'].map(l => (
            <a key={l} style={{ fontSize: 12, color: d.muted, textDecoration: 'none' }}>{l}</a>
          ))}
        </div>
        <div style={{ fontSize: 11, color: d.muted }}>© 2025 MOLDINVEST S.A. Licensed by CNPF Moldova.</div>
      </footer>

    </div>
  );
}
